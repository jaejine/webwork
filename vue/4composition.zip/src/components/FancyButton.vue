<template>
  <button class="fancy-btn">
    <slot>대체텍스트</slot>
  </button>
</template>